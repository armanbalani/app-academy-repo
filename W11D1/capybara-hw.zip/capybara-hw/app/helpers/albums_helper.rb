module AlbumsHelper
end
